package com.notnow.app.service

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardCapitalization
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.notnow.app.data.repository.FutureMessageRepository
import com.notnow.app.ui.theme.*
import kotlinx.coroutines.delay

@Composable
fun CountdownContent(
    appName: String,
    totalSec: Long,
    messageRepo: FutureMessageRepository,
    emergencyAvailable: Boolean,
    onOpen: () -> Unit,
    onGoBack: () -> Unit,
    onEmergency: () -> Unit
) {
    var remaining by remember { mutableLongStateOf(totalSec) }
    var futureMsg by remember { mutableStateOf("") }
    var showEmergencyConfirm by remember { mutableStateOf(false) }
    var emergencyPassword by remember { mutableStateOf("") }
    var emergencyPasswordError by remember { mutableStateOf(false) }

    LaunchedEffect(Unit) {
        futureMsg = messageRepo.getRandomMessage()?.message ?: ""
    }

    LaunchedEffect(remaining) {
        if (remaining <= 0L) return@LaunchedEffect  // timer done — show button, don't auto-open
        delay(1000L)
        remaining -= 1L
    }

    val timerDone = remaining <= 0L
    val progress = if (totalSec > 0) remaining.toFloat() / totalSec.toFloat() else 0f

    Box(
        modifier = Modifier.fillMaxSize().background(DeepNavy),
        contentAlignment = Alignment.Center
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(20.dp),
            modifier = Modifier.padding(32.dp)
        ) {
            Text("Not Now", style = MaterialTheme.typography.labelLarge, color = AccentAmber)

            if (timerDone) {
                Text("Time's up.", style = MaterialTheme.typography.headlineLarge, color = TextPrimary, textAlign = TextAlign.Center)
                Text("You waited. Do you still want to open $appName?", style = MaterialTheme.typography.bodyLarge, color = TextSecondary, textAlign = TextAlign.Center)
            } else {
                Text("Take a breath.", style = MaterialTheme.typography.headlineLarge, color = TextPrimary, textAlign = TextAlign.Center)
                Text("You were about to open $appName", style = MaterialTheme.typography.bodyLarge, color = TextSecondary, textAlign = TextAlign.Center)
            }

            Spacer(Modifier.height(4.dp))
            Box(contentAlignment = Alignment.Center) {
                CircularProgressIndicator(
                    progress = { if (timerDone) 0f else progress },
                    modifier = Modifier.size(140.dp),
                    color = if (timerDone) AccentGreen else AccentAmber,
                    trackColor = BorderDark,
                    strokeWidth = 6.dp
                )
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    if (timerDone) {
                        Text("✓", fontSize = 42.sp, color = AccentGreen, fontWeight = FontWeight.Bold)
                    } else {
                        val mins = remaining / 60
                        val secs = remaining % 60
                        Text(
                            if (mins > 0L) "%d:%02d".format(mins, secs) else "$secs",
                            fontSize = 42.sp,
                            color = TextPrimary,
                            fontWeight = FontWeight.Bold
                        )
                        if (totalSec >= 60) Text("min", style = MaterialTheme.typography.labelSmall, color = TextSecondary)
                        else Text("sec", style = MaterialTheme.typography.labelSmall, color = TextSecondary)
                    }
                }
            }

            if (!timerDone && futureMsg.isNotBlank()) {
                Surface(shape = RoundedCornerShape(12.dp), color = CardDark, modifier = Modifier.fillMaxWidth()) {
                    Text("\"$futureMsg\"", style = MaterialTheme.typography.bodyMedium, color = TextSecondary, textAlign = TextAlign.Center, modifier = Modifier.padding(16.dp))
                }
            }

            if (!timerDone) {
                Text("If you still want it after the timer, it's yours.", style = MaterialTheme.typography.bodyMedium, color = TextSecondary, textAlign = TextAlign.Center)
            }

            if (timerDone) {
                Button(
                    onClick = onOpen,
                    colors = ButtonDefaults.buttonColors(containerColor = AccentGreen),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text("Open $appName", color = Color.White, fontWeight = FontWeight.Bold)
                }
                OutlinedButton(
                    onClick = onGoBack,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text("Go Back Anyway", color = TextSecondary)
                }
            } else {
                Button(
                    onClick = onGoBack,
                    colors = ButtonDefaults.buttonColors(containerColor = CardDark),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Icon(Icons.Default.ArrowBack, null, tint = TextPrimary)
                    Spacer(Modifier.width(8.dp))
                    Text("Go Back", color = TextPrimary)
                }

                if (!emergencyAvailable) {
                    Text(
                        "Emergency unlock already used — available again in 8 hours.",
                        color = TextSecondary,
                        fontSize = 12.sp,
                        textAlign = TextAlign.Center
                    )
                } else if (!showEmergencyConfirm) {
                    TextButton(onClick = { showEmergencyConfirm = true }) {
                        Text("Emergency Unlock (15 min)", color = TextSecondary, fontSize = 12.sp)
                    }
                } else {
                    Surface(shape = RoundedCornerShape(12.dp), color = CardDark) {
                        Column(
                            Modifier.padding(16.dp),
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            Text("Emergency Unlock", color = AccentRed, style = MaterialTheme.typography.titleMedium)
                            Text(
                                "Type the password to unlock everything for 15 minutes.",
                                color = TextSecondary,
                                textAlign = TextAlign.Center,
                                style = MaterialTheme.typography.bodyMedium
                            )
                            OutlinedTextField(
                                value = emergencyPassword,
                                onValueChange = { emergencyPassword = it; emergencyPasswordError = false },
                                placeholder = { Text("Password", color = TextSecondary) },
                                singleLine = true,
                                isError = emergencyPasswordError,
                                visualTransformation = PasswordVisualTransformation(),
                                modifier = Modifier.fillMaxWidth(),
                                keyboardOptions = KeyboardOptions(capitalization = KeyboardCapitalization.None),
                                colors = OutlinedTextFieldDefaults.colors(
                                    focusedBorderColor = AccentRed,
                                    unfocusedBorderColor = BorderDark,
                                    focusedTextColor = TextPrimary,
                                    unfocusedTextColor = TextPrimary
                                )
                            )
                            if (emergencyPasswordError) {
                                Text("Wrong password", color = AccentRed, style = MaterialTheme.typography.bodySmall)
                            }
                            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                                OutlinedButton(
                                    onClick = {
                                        showEmergencyConfirm = false
                                        emergencyPassword = ""
                                        emergencyPasswordError = false
                                    },
                                    modifier = Modifier.weight(1f)
                                ) { Text("Cancel", color = TextSecondary) }
                                Button(
                                    onClick = {
                                        if (emergencyPassword == "Areyousure?") onEmergency()
                                        else emergencyPasswordError = true
                                    },
                                    colors = ButtonDefaults.buttonColors(containerColor = AccentRed),
                                    modifier = Modifier.weight(1f)
                                ) { Text("Unlock", color = Color.White) }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun NightBlockContent(appName: String, onBack: () -> Unit) {
    Box(
        modifier = Modifier.fillMaxSize().background(DeepNavy),
        contentAlignment = Alignment.Center
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(20.dp),
            modifier = Modifier.padding(32.dp)
        ) {
            Text("🌙", fontSize = 64.sp)
            Text("Night Lockdown", style = MaterialTheme.typography.headlineMedium, color = TextPrimary, textAlign = TextAlign.Center)
            Text("$appName is locked until morning.\nRest well.", style = MaterialTheme.typography.bodyLarge, color = TextSecondary, textAlign = TextAlign.Center)
            Spacer(Modifier.height(8.dp))
            Button(onClick = onBack, colors = ButtonDefaults.buttonColors(containerColor = CardDark), modifier = Modifier.fillMaxWidth()) {
                Text("Go Back", color = TextPrimary)
            }
        }
    }
}

@Composable
fun WorkWarningContent(initialSecondsLeft: Int) {
    var secondsLeft by remember { mutableIntStateOf(initialSecondsLeft) }

    LaunchedEffect(secondsLeft) {
        if (secondsLeft <= 0) return@LaunchedEffect
        delay(1000L)
        secondsLeft -= 1
    }

    // Non-blocking banner: the app underneath stays usable so the user can
    // save/finish what they're doing (and answer calls) before lockdown begins.
    Box(modifier = Modifier.fillMaxWidth().padding(top = 36.dp, start = 12.dp, end = 12.dp)) {
        Surface(shape = RoundedCornerShape(14.dp), color = AccentAmber, shadowElevation = 8.dp) {
            Row(
                modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 12.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Column(Modifier.weight(1f)) {
                    Text("⚠️ Work Lockdown Starting", style = MaterialTheme.typography.titleMedium, color = DeepNavy, fontWeight = FontWeight.Bold)
                    Text("Finish up and save your work", style = MaterialTheme.typography.bodySmall, color = DeepNavy)
                }
                Spacer(Modifier.width(12.dp))
                Text("${secondsLeft.coerceAtLeast(0)}s", fontSize = 28.sp, color = DeepNavy, fontWeight = FontWeight.Bold)
            }
        }
    }
}

@Composable
fun PhoneGraceBannerContent(initialSecondsLeft: Int) {
    var secondsLeft by remember { mutableIntStateOf(initialSecondsLeft) }
    LaunchedEffect(secondsLeft) {
        if (secondsLeft <= 0) return@LaunchedEffect
        delay(1000L)
        secondsLeft -= 1
    }
    val mins = secondsLeft / 60
    val secs = secondsLeft % 60
    val timeStr = if (mins > 0) "%d:%02d".format(mins, secs) else "${secs}s"
    Box(modifier = Modifier.fillMaxWidth().padding(top = 36.dp, start = 12.dp, end = 12.dp)) {
        Surface(shape = RoundedCornerShape(14.dp), color = AccentBlue, shadowElevation = 8.dp) {
            Row(
                modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 12.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Column(Modifier.weight(1f)) {
                    Text("📱 Phone access active", style = MaterialTheme.typography.titleMedium, color = Color.White, fontWeight = FontWeight.Bold)
                    Text("Lockdown resumes automatically", style = MaterialTheme.typography.bodySmall, color = Color.White.copy(alpha = 0.85f))
                }
                Spacer(Modifier.width(12.dp))
                Text(timeStr, fontSize = 28.sp, color = Color.White, fontWeight = FontWeight.Bold)
            }
        }
    }
}

@Composable
fun WorkLockdownContent(
    initialRemainingMs: Long,
    emergencyAvailable: Boolean,
    emergencyCooldownRemainingMs: Long,
    onEmergency: () -> Unit,
    onOpenPhone: () -> Unit
) {
    var remainingMs by remember { mutableLongStateOf(initialRemainingMs) }
    var cooldownMs by remember { mutableLongStateOf(emergencyCooldownRemainingMs) }
    var showEmergencyConfirm by remember { mutableStateOf(false) }
    var emergencyPassword by remember { mutableStateOf("") }
    var emergencyPasswordError by remember { mutableStateOf(false) }

    LaunchedEffect(remainingMs) {
        if (remainingMs <= 0L) return@LaunchedEffect
        delay(1000L)
        remainingMs = (remainingMs - 1000L).coerceAtLeast(0L)
    }

    LaunchedEffect(Unit) {
        while (cooldownMs > 0L) {
            delay(1000L)
            cooldownMs = (cooldownMs - 1000L).coerceAtLeast(0L)
        }
    }

    val mins = remainingMs / 60000L
    val secs = (remainingMs / 1000L) % 60L

    Box(
        modifier = Modifier.fillMaxSize().background(DeepNavy),
        contentAlignment = Alignment.Center
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(20.dp),
            modifier = Modifier.padding(32.dp)
        ) {
            Text("🔒", fontSize = 64.sp)
            Text("Work Lockdown", style = MaterialTheme.typography.headlineMedium, color = TextPrimary, textAlign = TextAlign.Center)
            Text(
                "Stay focused. The phone is locked for this work block.",
                style = MaterialTheme.typography.bodyLarge, color = TextSecondary, textAlign = TextAlign.Center
            )
            Text(
                "%d:%02d".format(mins, secs),
                fontSize = 56.sp,
                color = AccentBlue,
                fontWeight = FontWeight.Bold
            )
            Text("until your next 15-minute break", style = MaterialTheme.typography.labelSmall, color = TextSecondary)

            Surface(shape = RoundedCornerShape(10.dp), color = AccentGreen.copy(alpha = 0.15f), modifier = Modifier.fillMaxWidth()) {
                Column(
                    modifier = Modifier.padding(horizontal = 16.dp, vertical = 12.dp).fillMaxWidth(),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text("📞", fontSize = 20.sp)
                        Spacer(Modifier.width(10.dp))
                        Text("Phone calls are still available", color = AccentGreen, style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.Bold)
                    }
                    Button(
                        onClick = onOpenPhone,
                        colors = ButtonDefaults.buttonColors(containerColor = AccentGreen),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text("Open Phone App", color = Color.White, fontWeight = FontWeight.Bold)
                    }
                }
            }

            Spacer(Modifier.height(4.dp))

            if (!emergencyAvailable) {
                val cooldownMin = cooldownMs / 60000L
                val cooldownH = cooldownMin / 60L
                val cooldownM = cooldownMin % 60L
                val cooldownStr = when {
                    cooldownH > 0L && cooldownM > 0L -> "${cooldownH}h ${cooldownM}m"
                    cooldownH > 0L -> "${cooldownH}h"
                    else -> "${cooldownM}m"
                }
                Text(
                    "Emergency unlock already used — available again in $cooldownStr.",
                    color = TextSecondary,
                    fontSize = 12.sp,
                    textAlign = TextAlign.Center
                )
            } else if (!showEmergencyConfirm) {
                TextButton(onClick = { showEmergencyConfirm = true }) {
                    Text("Emergency Unlock (15 min)", color = TextSecondary, fontSize = 12.sp)
                }
            } else {
                Surface(shape = RoundedCornerShape(12.dp), color = CardDark) {
                    Column(
                        Modifier.padding(16.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Text("Emergency Unlock", color = AccentRed, style = MaterialTheme.typography.titleMedium)
                        Text(
                            "Type the password to pause Work Lockdown for 15 minutes.\nThis can only be used once every 9 hours.",
                            color = TextSecondary,
                            textAlign = TextAlign.Center,
                            style = MaterialTheme.typography.bodyMedium
                        )
                        OutlinedTextField(
                            value = emergencyPassword,
                            onValueChange = { emergencyPassword = it; emergencyPasswordError = false },
                            placeholder = { Text("Password", color = TextSecondary) },
                            singleLine = true,
                            isError = emergencyPasswordError,
                            visualTransformation = PasswordVisualTransformation(),
                            modifier = Modifier.fillMaxWidth(),
                            keyboardOptions = KeyboardOptions(capitalization = KeyboardCapitalization.None),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = AccentRed,
                                unfocusedBorderColor = BorderDark,
                                focusedTextColor = TextPrimary,
                                unfocusedTextColor = TextPrimary
                            )
                        )
                        if (emergencyPasswordError) {
                            Text("Wrong password", color = AccentRed, style = MaterialTheme.typography.bodySmall)
                        }
                        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                            OutlinedButton(
                                onClick = {
                                    showEmergencyConfirm = false
                                    emergencyPassword = ""
                                    emergencyPasswordError = false
                                },
                                modifier = Modifier.weight(1f)
                            ) { Text("Cancel", color = TextSecondary) }
                            Button(
                                onClick = {
                                    if (emergencyPassword == "Areyousure?") onEmergency()
                                    else emergencyPasswordError = true
                                },
                                colors = ButtonDefaults.buttonColors(containerColor = AccentRed),
                                modifier = Modifier.weight(1f)
                            ) { Text("Unlock", color = Color.White) }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun ShoppingPauseContent(
    appName: String,
    delayMinutes: Long,
    onBuyNow: () -> Unit,
    onSaveForLater: (title: String, url: String, price: String) -> Unit,
    onGoBack: () -> Unit
) {
    var showForm by remember { mutableStateOf(false) }
    var title by remember { mutableStateOf("") }
    var url   by remember { mutableStateOf("") }
    var price by remember { mutableStateOf("") }

    Box(modifier = Modifier.fillMaxSize().background(DeepNavy), contentAlignment = Alignment.Center) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(16.dp),
            modifier = Modifier.padding(32.dp)
        ) {
            Text("🛍️", fontSize = 56.sp)
            Text("Spending Pause", style = MaterialTheme.typography.headlineMedium, color = TextPrimary, textAlign = TextAlign.Center)
            Text("You're about to open $appName.\nDo you need this right now?", style = MaterialTheme.typography.bodyLarge, color = TextSecondary, textAlign = TextAlign.Center)

            if (!showForm) {
                Button(onClick = onBuyNow, colors = ButtonDefaults.buttonColors(containerColor = AccentAmber), modifier = Modifier.fillMaxWidth()) {
                    Text("Buy Now  (wait $delayMinutes min)", color = DeepNavy)
                }
                Button(onClick = { showForm = true }, colors = ButtonDefaults.buttonColors(containerColor = AccentGreen), modifier = Modifier.fillMaxWidth()) {
                    Text("Save for Later", color = Color.White)
                }
                OutlinedButton(onClick = onGoBack, modifier = Modifier.fillMaxWidth()) {
                    Text("Go Back", color = TextSecondary)
                }
            } else {
                Surface(shape = RoundedCornerShape(16.dp), color = CardDark, modifier = Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                        Text("Save to Vault", style = MaterialTheme.typography.titleMedium, color = TextPrimary)
                        OutlinedTextField(value = title, onValueChange = { title = it }, label = { Text("What is it?") }, modifier = Modifier.fillMaxWidth(), singleLine = true,
                            keyboardOptions = KeyboardOptions(capitalization = KeyboardCapitalization.Sentences),
                            colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = AccentAmber, unfocusedBorderColor = BorderDark, focusedLabelColor = AccentAmber, unfocusedLabelColor = TextSecondary))
                        OutlinedTextField(value = price, onValueChange = { price = it }, label = { Text("Price (optional)") }, modifier = Modifier.fillMaxWidth(), singleLine = true,
                            colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = AccentAmber, unfocusedBorderColor = BorderDark, focusedLabelColor = AccentAmber, unfocusedLabelColor = TextSecondary))
                        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                            OutlinedButton(onClick = { showForm = false }, modifier = Modifier.weight(1f)) { Text("Cancel", color = TextSecondary) }
                            Button(onClick = { if (title.isNotBlank()) onSaveForLater(title, url, price) }, enabled = title.isNotBlank(),
                                colors = ButtonDefaults.buttonColors(containerColor = AccentAmber), modifier = Modifier.weight(1f)) { Text("Save", color = DeepNavy) }
                        }
                    }
                }
            }
        }
    }
}
